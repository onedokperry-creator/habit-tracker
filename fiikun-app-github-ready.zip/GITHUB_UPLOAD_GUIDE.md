﻿# GitHubへアップロードする手順

## ブラウザだけでアップロードする場合

1. GitHubで新しいリポジトリを作成
2. `Add file` → `Upload files`
3. このフォルダの中身をすべてドラッグ&ドロップ
4. `Commit changes`
5. `Settings` → `Pages` でGitHub Pagesを有効化

アップロードするもの:

```text
index.html
styles.css
app.js
assets/
README.md
```

## Gitコマンドでアップロードする場合

```bash
git init
git add .
git commit -m "Add fiikun app"
git branch -M main
git remote add origin https://github.com/YOUR_NAME/YOUR_REPOSITORY.git
git push -u origin main
```

その後、GitHubの `Settings` → `Pages` で公開してください。
