﻿# ふぃーくんといちご畑

タスク、ポモドーロ、達成記録、ごほうびをまとめた静的Webアプリです。
HTML / CSS / JavaScriptだけで動くので、GitHub Pagesに置くだけで各端末から利用できます。

## ファイル構成

```text
fiikun-app/
├─ index.html
├─ styles.css
├─ app.js
└─ assets/
   ├─ *.png
   └─ plants/
      └─ pot_stage1.png ... pot_stage8.png
```

## ローカルで開く

`index.html` をブラウザで開いてください。
データはブラウザの `localStorage` に保存されます。

## GitHub Pagesで公開する

1. GitHubで新しいリポジトリを作成します。
2. このフォルダ内の全ファイルをアップロードします。
3. GitHubの `Settings` → `Pages` を開きます。
4. `Build and deployment` の `Source` を `Deploy from a branch` にします。
5. `Branch` を `main` / `/root` にして保存します。
6. 表示されたURLを開くと、各端末から同じアプリを表示できます。

## 注意

- 端末ごとの入力データは、それぞれのブラウザ内に保存されます。
- Google FontsのKiwi Maruを読み込むため、初回表示時にインターネット接続が必要です。
- 画像ファイルは `assets` フォルダの相対パスで参照しています。フォルダ名を変える場合は、HTML/JS内の参照も合わせて変更してください。
