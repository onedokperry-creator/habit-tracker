# ふぃーくんアプリ コード全文

画像はバイナリファイルなので、GitHubには ssets/ フォルダごとアップロードしてください。

## index.html
``html
<!doctype html>
<html lang="ja">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />
    <title>ふぃーくんといちご畑</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Kiwi+Maru&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="./styles.css" />
  </head>
  <body>
    <div class="app-shell">
      <main class="main-area">
        <section class="view active" id="home-view" aria-labelledby="home-title">
          <header class="page-header">
            <div>
              <p class="eyebrow">Home</p>
              <h1 id="home-title">ふぃーくんと<br />いちご畑</h1>
            </div>
            <img src="./assets/fiikun_happy.png" alt="笑顔のふぃーくん" class="header-bunny" />
          </header>

          <section class="panel home-field-panel" aria-labelledby="field-title">
            <div class="section-heading">
              <h2 id="field-title">今日のいちご畑</h2>
              <span id="progress-label">0 / 0</span>
            </div>
            <div class="home-field-grid">
              <div class="home-fiikun-area">
                <div class="letter-speech" id="home-letter-notice" hidden>
                  <img src="./assets/letter.png" alt="" />
                  <span>おてがみが届いているよ</span>
                </div>
                <img id="home-fiikun-image" src="./assets/fiikun_normal.png" alt="ふぃーくん" class="hero-bunny" />
              </div>
              <div class="home-garden-area">
                <p class="garden-subtitle">畑のようす</p>
                <div class="garden-visual home-garden-visual">
                  <img id="home-garden-stage-image" src="./assets/plants/pot_stage1.png" alt="畑の成長ステージ" />
                  <div class="garden-fallback" id="home-garden-fallback">
                    <img src="./assets/plant.png" alt="" />
                    <span>assets/plants/pot_stage1.png</span>
                  </div>
                </div>
                <div class="garden-progress home-garden-progress" aria-label="畑の成長">
                  <span id="home-garden-progress-bar"></span>
                </div>
              </div>
            </div>
            <p class="hint-text" id="field-message">タスクを追加して、いちご畑を育てよう。</p>
          </section>

          <section class="panel today-panel" aria-labelledby="today-title">
            <div class="section-heading">
              <h2 id="today-title">今日のタスク</h2>
              <button class="text-button" type="button" data-jump="tasks">見る</button>
            </div>
            <div class="mini-task-list" id="home-task-list"></div>
          </section>

          <section class="panel pomodoro-summary" aria-labelledby="pomodoro-summary-title">
            <div class="section-heading">
              <h2 id="pomodoro-summary-title">今日の集中</h2>
              <button class="text-button" type="button" data-jump="timer">タイマーへ</button>
            </div>
            <div class="summary-row">
              <img src="./assets/clock.png" alt="" />
              <div>
                <strong id="today-pomo-count">0回</strong>
                <span id="today-pomo-minutes">0分</span>
              </div>
              <img src="./assets/fiikun_normal.png" alt="ふぃーくん" class="summary-bunny" />
            </div>
          </section>
        </section>

        <section class="view" id="tasks-view" aria-labelledby="tasks-title">
          <header class="page-header compact">
            <div>
              <p class="eyebrow">Tasks</p>
              <h1 id="tasks-title">タスク管理</h1>
            </div>
            <img src="./assets/fiikun_think.png" alt="考えるふぃーくん" class="header-bunny" />
          </header>

          <section class="panel task-composer" aria-label="タスク追加">
            <form id="task-form">
              <label>
                タスク名
                <input id="task-title" type="text" placeholder="例：朝のストレッチ 5分" autocomplete="off" required />
              </label>
              <div class="form-row">
                <label>
                  種類
                  <select id="task-category">
                    <option value="Main">Main</option>
                    <option value="Sub">Sub</option>
                    <option value="Tiny">Tiny</option>
                  </select>
                </label>
                <label>
                  アイコン
                  <select id="task-icon">
                    <option value="strawberry.png">いちご</option>
                    <option value="book.png">読書</option>
                    <option value="dumbbell.png">運動</option>
                    <option value="cup.png">休憩</option>
                    <option value="pencil.png">勉強</option>
                    <option value="flower.png">ケア</option>
                  </select>
                </label>
              </div>
              <button class="primary-button" type="submit">
                <img src="./assets/plant.png" alt="" />
                追加
              </button>
            </form>
          </section>

          <section class="panel task-board" aria-labelledby="task-board-title">
            <div class="section-heading task-heading">
              <div>
                <h2 id="task-board-title">今日のタスク</h2>
                <p id="task-count">0件</p>
              </div>
              <div class="filter-tabs" role="tablist" aria-label="タスク表示フィルター">
                <button class="filter-tab active" type="button" data-filter="all">すべて</button>
                <button class="filter-tab" type="button" data-filter="Main">Main</button>
                <button class="filter-tab" type="button" data-filter="Sub">Sub</button>
                <button class="filter-tab" type="button" data-filter="Tiny">Tiny</button>
              </div>
            </div>
            <div class="task-list" id="task-list"></div>
          </section>
        </section>

        <section class="view" id="timer-view" aria-labelledby="timer-title">
          <header class="page-header compact">
            <div>
              <p class="eyebrow">Pomodoro</p>
              <h1 id="timer-title">ポモドーロタイマー</h1>
            </div>
            <img src="./assets/fiikun_stand.png" alt="応援するふぃーくん" class="header-bunny" />
          </header>

          <section class="panel timer-panel" aria-label="ポモドーロタイマー">
            <div class="timer-ring" id="timer-ring">
              <img src="./assets/strawberry.png" alt="" />
              <p id="timer-mode">集中時間</p>
              <strong id="timer-display">25:00</strong>
            </div>
            <div class="timer-controls">
              <button class="primary-button" type="button" id="timer-start">スタート</button>
              <button class="secondary-button" type="button" id="timer-reset">リセット</button>
              <button class="secondary-button" type="button" id="timer-complete">記録する</button>
            </div>
            <div class="timer-settings" aria-label="タイマー設定">
              <button class="duration-chip active" type="button" data-minutes="25">25分</button>
              <button class="duration-chip" type="button" data-minutes="15">15分</button>
              <button class="duration-chip" type="button" data-minutes="5">5分</button>
            </div>
          </section>

          <section class="panel record-panel" aria-labelledby="record-title">
            <div class="section-heading">
              <div>
                <h2 id="record-title">今日の記録</h2>
                <p id="record-total">0回 / 0分</p>
              </div>
              <button class="text-button" type="button" id="clear-records">クリア</button>
            </div>
            <div class="record-list" id="record-list"></div>
          </section>
        </section>

        <section class="view" id="records-view" aria-labelledby="records-title">
          <header class="page-header compact">
            <div>
              <p class="eyebrow">Records</p>
              <h1 id="records-title">達成記録</h1>
            </div>
            <img src="./assets/fiikun_letter.png" alt="手紙を持つふぃーくん" class="header-bunny" />
          </header>

          <section class="panel calendar-panel" aria-labelledby="calendar-title">
            <div class="calendar-header">
              <button class="icon-button" type="button" id="prev-month" aria-label="前の月">‹</button>
              <h2 id="calendar-title">2026年6月</h2>
              <button class="icon-button" type="button" id="next-month" aria-label="次の月">›</button>
            </div>
            <div class="calendar-weekdays" aria-hidden="true">
              <span>日</span><span>月</span><span>火</span><span>水</span><span>木</span><span>金</span><span>土</span>
            </div>
            <div class="calendar-grid" id="calendar-grid" aria-label="達成記録カレンダー"></div>
            <div class="calendar-legend" aria-label="達成アイコンの説明">
              <span><img src="./assets/strawberry.png" alt="" />Main</span>
              <span><img src="./assets/flower.png" alt="" />Sub</span>
              <span><img src="./assets/clock.png" alt="" />Pomodoro</span>
              <span><img src="./assets/gift.png" alt="" />全部達成</span>
            </div>
          </section>

          <section class="panel letter-panel" aria-labelledby="letter-title">
            <div class="section-heading">
              <div>
                <h2 id="letter-title">ふぃーくんからのお手紙</h2>
                <p id="letter-date">今日</p>
              </div>
              <img src="./assets/letter.png" alt="" class="letter-icon" />
            </div>
            <div class="letter-card">
              <p class="letter-greeting">みおさんへ</p>
              <p id="letter-body">日付を選ぶと、ふぃーくんからのお手紙が届きます。</p>
              <p class="letter-sign">ふぃーくんより</p>
            </div>
          </section>
        </section>

        <section class="view" id="rewards-view" aria-labelledby="rewards-title">
          <header class="page-header compact">
            <div>
              <p class="eyebrow">Rewards</p>
              <h1 id="rewards-title">ごほうびリスト</h1>
            </div>
            <img src="./assets/fiikun_king.png" alt="王冠のふぃーくん" class="header-bunny" />
          </header>

          <section class="panel garden-panel" aria-labelledby="garden-title">
            <div class="section-heading">
              <div>
                <h2 id="garden-title">いちご畑</h2>
                <p id="garden-stage-label">ステージ 1 / 8</p>
              </div>
              <span class="points-pill"><img src="./assets/strawberry.png" alt="" /><strong id="strawberry-points">0</strong></span>
            </div>
            <div class="garden-visual">
              <img id="garden-stage-image" src="./assets/plants/pot_stage1.png" alt="畑の成長ステージ" />
              <div class="garden-fallback" id="garden-fallback">
                <img src="./assets/plant.png" alt="" />
                <span>assets/plants/pot_stage1.png</span>
              </div>
            </div>
            <div class="garden-progress" aria-label="畑の成長">
              <span id="garden-progress-bar"></span>
            </div>
            <p class="hint-text" id="garden-message">タスクを達成すると、いちごポイントと畑の成長が進みます。</p>
          </section>

          <section class="panel reward-shop-panel" aria-labelledby="reward-shop-title">
            <div class="section-heading">
              <div>
                <h2 id="reward-shop-title">ごほうび交換</h2>
                <p class="small-note">交換するとポイントを使います。</p>
              </div>
              <img src="./assets/gift.png" alt="" class="letter-icon" />
            </div>
            <form class="reward-form" id="reward-form">
              <input id="reward-title-input" type="text" placeholder="ごほうび名" autocomplete="off" required />
              <input id="reward-cost-input" type="number" min="1" max="999" value="5" aria-label="必要ポイント" />
              <button class="primary-button" type="submit">追加</button>
            </form>
            <div class="reward-list" id="reward-list"></div>
          </section>

          <section class="panel letters-unlock-panel" aria-labelledby="letters-unlock-title">
            <div class="section-heading">
              <div>
                <h2 id="letters-unlock-title">おてがみ解放</h2>
                <p class="small-note">畑の成長に合わせて、ふぃーくんから届きます。</p>
              </div>
              <img src="./assets/letter.png" alt="" class="letter-icon" />
            </div>
            <div class="letter-unlock-list" id="letter-unlock-list"></div>
          </section>

          <section class="panel outfit-panel" aria-labelledby="outfit-title">
            <div class="section-heading">
              <div>
                <h2 id="outfit-title">ふぃーくん衣装</h2>
                <p class="small-note">今は通常のみ。将来の衣装を追加できます。</p>
              </div>
            </div>
            <div class="outfit-list" id="outfit-list"></div>
          </section>

          <section class="panel album-panel" aria-labelledby="album-title">
            <div class="section-heading">
              <div>
                <h2 id="album-title">思い出アルバム</h2>
                <p class="small-note">将来の実績をここに追加できます。</p>
              </div>
            </div>
            <div class="achievement-list" id="achievement-list"></div>
          </section>

          <div class="animation-container" id="reward-animation" aria-hidden="true"></div>
        </section>
      </main>

      <nav class="bottom-tabs" aria-label="主要画面">
        <button class="bottom-tab active" type="button" data-view="home" aria-current="page">
          <img src="./assets/plant.png" alt="" />
          <span>ホーム</span>
        </button>
        <button class="bottom-tab" type="button" data-view="tasks">
          <img src="./assets/pencil.png" alt="" />
          <span>タスク</span>
        </button>
        <button class="bottom-tab" type="button" data-view="timer">
          <img src="./assets/clock.png" alt="" />
          <span>タイマー</span>
        </button>
        <button class="bottom-tab" type="button" data-view="records">
          <img src="./assets/letter.png" alt="" />
          <span>記録</span>
        </button>
        <button class="bottom-tab" type="button" data-view="rewards">
          <img src="./assets/gift.png" alt="" />
          <span>ごほうび</span>
        </button>
      </nav>
    </div>

    <script src="./app.js"></script>
  </body>
</html>

``

## styles.css
``css
:root {
  --bg: #fff8f4;
  --surface: #fffdf9;
  --surface-soft: #fff1ef;
  --line: #eadbd2;
  --ink: #4b3c35;
  --muted: #8f7d74;
  --pink: #ee9da0;
  --pink-deep: #dd7d83;
  --mint: #dfece1;
  --cream: #fff8ec;
  --shadow: 0 14px 34px rgba(120, 88, 72, 0.11);
}

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  min-height: 100vh;
  color: var(--ink);
  background:
    radial-gradient(circle at top left, rgba(255, 238, 243, 0.86), transparent 24rem),
    linear-gradient(145deg, #fffaf6 0%, var(--bg) 56%, #f9f7ef 100%);
  font-family: "Kiwi Maru", "Yu Gothic", "Hiragino Kaku Gothic ProN", serif;
  letter-spacing: 0;
}

button,
input,
select {
  font: inherit;
}

button {
  cursor: pointer;
}

.app-shell {
  width: min(100%, 480px);
  min-height: 100vh;
  margin: 0 auto;
  padding: 12px 12px calc(94px + env(safe-area-inset-bottom));
}

.main-area {
  min-width: 0;
}

.view {
  display: none;
}

.view.active {
  display: grid;
  gap: 14px;
}

.panel,
.page-header,
.bottom-tabs {
  border: 1px solid var(--line);
  background: rgba(255, 253, 249, 0.9);
  box-shadow: var(--shadow);
  backdrop-filter: blur(12px);
}

.page-header {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 110px;
  gap: 12px;
  align-items: end;
  min-height: 132px;
  padding: 18px;
  overflow: hidden;
  border-radius: 8px;
}

.page-header.compact {
  min-height: 108px;
}

.eyebrow {
  margin: 0 0 5px;
  color: var(--pink-deep);
  font-size: 12px;
  font-weight: 700;
}

h1,
h2,
p {
  margin-top: 0;
}

h1 {
  margin-bottom: 8px;
  font-size: 28px;
  line-height: 1.22;
}

h2 {
  margin-bottom: 0;
  font-size: 18px;
  line-height: 1.35;
}

.page-lead {
  margin-bottom: 0;
  color: var(--muted);
  font-size: 14px;
  line-height: 1.65;
}

.header-bunny {
  justify-self: end;
  align-self: end;
  width: 108px;
  max-height: 130px;
  object-fit: contain;
}

.panel {
  border-radius: 8px;
  padding: 16px;
}

.hero-panel {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 130px;
  align-items: end;
  min-height: 218px;
  overflow: hidden;
  background:
    linear-gradient(135deg, rgba(255, 241, 239, 0.92), rgba(255, 253, 249, 0.78)),
    var(--surface);
}

.soft-badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 14px;
  padding: 8px 10px;
  border: 1px dashed #e6cabd;
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.78);
  color: var(--muted);
  font-size: 12px;
}

.soft-badge img,
.primary-button img {
  width: 20px;
  height: 20px;
  object-fit: contain;
}

.hero-panel p,
.hint-text {
  color: var(--muted);
  font-size: 13px;
  line-height: 1.7;
}

.hero-bunny {
  justify-self: end;
  width: 126px;
}

.section-heading {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
  margin-bottom: 14px;
}

.section-heading span,
#task-count,
#record-total {
  margin: 4px 0 0;
  color: var(--muted);
  font-size: 13px;
}

.text-button {
  min-height: 34px;
  border: 0;
  color: var(--pink-deep);
  background: transparent;
  font-weight: 700;
}

.strawberry-field {
  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));
  gap: 8px;
}

.garden-visual.home-garden-visual {
  min-height: 170px;
}

.garden-visual.home-garden-visual > img {
  width: min(72%, 210px);
  max-height: 150px;
}

.home-garden-progress {
  margin-top: 12px;
}

.home-field-panel {
  display: grid;
  gap: 12px;
}

.home-field-grid {
  display: grid;
  grid-template-columns: minmax(0, 128px) minmax(0, 1fr);
  gap: 14px;
  align-items: end;
}

.home-fiikun-area {
  position: relative;
  display: grid;
  align-items: end;
  min-height: 184px;
}

.home-fiikun-area .hero-bunny {
  justify-self: center;
  width: min(100%, 124px);
  max-height: 150px;
  object-fit: contain;
}

.letter-speech {
  position: relative;
  z-index: 1;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  width: fit-content;
  max-width: 132px;
  margin: 0 auto -4px;
  padding: 8px 10px;
  border: 1px solid var(--line);
  border-radius: 8px;
  background: #fff;
  color: var(--ink);
  font-size: 12px;
  font-weight: 700;
  line-height: 1.45;
  box-shadow: 0 8px 18px rgba(120, 88, 72, 0.1);
}

.letter-speech::after {
  content: "";
  position: absolute;
  left: 50%;
  bottom: -7px;
  width: 12px;
  height: 12px;
  border-right: 1px solid var(--line);
  border-bottom: 1px solid var(--line);
  background: #fff;
  transform: translateX(-50%) rotate(45deg);
}

.letter-speech img {
  flex: 0 0 auto;
  width: 18px;
  height: 18px;
  object-fit: contain;
}

.letter-speech[hidden] {
  display: none;
}

.garden-subtitle {
  margin: 0 0 8px;
  color: var(--muted);
  font-size: 13px;
  font-weight: 700;
}

.berry-plot {
  display: grid;
  place-items: center;
  min-height: 48px;
  border: 1px solid var(--line);
  border-radius: 8px;
  background: #fffaf5;
}

.berry-plot img {
  width: 28px;
  height: 28px;
  object-fit: contain;
  opacity: 0.3;
  filter: saturate(0.55);
}

.berry-plot.done {
  background: var(--surface-soft);
}

.berry-plot.done img {
  opacity: 1;
  filter: none;
}

.hint-text {
  margin: 12px 0 0;
}

.mini-task-list,
.task-list,
.record-list,
.reward-list,
.letter-unlock-list,
.outfit-list,
.achievement-list {
  display: grid;
  gap: 10px;
}

.mini-task,
.task-item,
.record-item {
  display: grid;
  grid-template-columns: 34px minmax(0, 1fr) auto;
  gap: 10px;
  align-items: center;
  padding: 12px;
  border: 1px solid var(--line);
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.72);
}

.task-item {
  grid-template-columns: 34px minmax(0, 1fr);
}

.mini-task img,
.task-icon-img,
.record-item img {
  width: 30px;
  height: 30px;
  object-fit: contain;
}

.task-title,
.record-title {
  margin: 0;
  font-weight: 700;
}

.task-meta,
.record-meta {
  margin: 3px 0 0;
  color: var(--muted);
  font-size: 12px;
}

.category-pill {
  padding: 5px 9px;
  border-radius: 8px;
  background: var(--mint);
  color: #637565;
  font-size: 12px;
  font-weight: 700;
}

.category-pill.Main {
  background: #ffe4e4;
  color: #b96c71;
}

.category-pill.Sub {
  background: #eee8f7;
  color: #786999;
}

.category-pill.Tiny {
  background: #e9f1dc;
  color: #6f7c55;
}

.summary-row {
  display: grid;
  grid-template-columns: 44px minmax(0, 1fr) 78px;
  gap: 12px;
  align-items: center;
}

.summary-row > img:first-child {
  width: 38px;
}

.summary-row strong {
  display: block;
  font-size: 24px;
}

.summary-row span {
  color: var(--muted);
  font-size: 13px;
}

.summary-bunny {
  width: 78px;
  max-height: 96px;
  object-fit: contain;
}

#task-form {
  display: grid;
  gap: 12px;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
}

label {
  display: grid;
  gap: 7px;
  color: var(--muted);
  font-size: 13px;
  font-weight: 700;
}

input,
select {
  width: 100%;
  min-height: 46px;
  border: 1px solid var(--line);
  border-radius: 8px;
  padding: 0 12px;
  color: var(--ink);
  background: #fff;
  outline: none;
}

input:focus,
select:focus {
  border-color: var(--pink);
  box-shadow: 0 0 0 3px rgba(238, 157, 160, 0.18);
}

.primary-button,
.secondary-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  min-height: 46px;
  border-radius: 8px;
  padding: 0 16px;
  font-weight: 700;
}

.primary-button {
  border: 0;
  color: #fff;
  background: var(--pink);
  box-shadow: 0 10px 24px rgba(221, 125, 131, 0.24);
}

.secondary-button {
  border: 1px solid var(--line);
  color: var(--ink);
  background: #fff;
}

.task-heading {
  display: grid;
}

.filter-tabs,
.timer-settings {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 6px;
  width: 100%;
  padding: 4px;
  border: 1px solid var(--line);
  border-radius: 8px;
  background: #fffaf5;
}

.filter-tab,
.duration-chip {
  min-height: 38px;
  border: 0;
  border-radius: 6px;
  padding: 8px 6px;
  color: var(--muted);
  background: transparent;
  font-size: 13px;
}

.filter-tab.active,
.duration-chip.active {
  color: var(--ink);
  background: #fff;
  box-shadow: 0 6px 15px rgba(120, 88, 72, 0.08);
}

.task-item.done .task-title {
  color: var(--muted);
  text-decoration: line-through;
}

.task-item .category-pill {
  grid-column: 2;
  justify-self: start;
}

.task-actions {
  grid-column: 2;
  display: flex;
  gap: 8px;
}

.check-button,
.delete-button {
  display: grid;
  place-items: center;
  width: 38px;
  height: 34px;
  border: 1px solid var(--line);
  border-radius: 8px;
  background: #fff;
}

.check-button {
  color: var(--pink-deep);
}

.delete-button {
  color: var(--muted);
}

.timer-panel {
  display: grid;
  justify-items: center;
  gap: 16px;
}

.timer-ring {
  display: grid;
  place-items: center;
  align-content: center;
  width: min(74vw, 270px);
  aspect-ratio: 1;
  border: 9px solid rgba(238, 157, 160, 0.26);
  border-radius: 50%;
  background:
    radial-gradient(circle, #fffdf9 58%, rgba(255, 241, 239, 0.78) 59%),
    var(--surface-soft);
}

.timer-ring img {
  width: 34px;
  height: 34px;
  object-fit: contain;
}

.timer-ring p {
  margin: 8px 0 4px;
  color: var(--muted);
  font-size: 13px;
  font-weight: 700;
}

.timer-ring strong {
  font-size: 48px;
  line-height: 1;
  color: var(--pink-deep);
}

.timer-controls {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  width: 100%;
}

#timer-complete {
  grid-column: 1 / -1;
}

.timer-settings {
  grid-template-columns: repeat(3, 1fr);
}

.record-item {
  grid-template-columns: 34px minmax(0, 1fr) auto;
}

.points-pill {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-height: 34px;
  padding: 6px 10px;
  border: 1px solid var(--line);
  border-radius: 8px;
  background: var(--surface-soft);
  color: var(--pink-deep);
  font-size: 14px;
}

.points-pill img {
  width: 22px;
  height: 22px;
  object-fit: contain;
}

.small-note {
  margin: 4px 0 0;
  color: var(--muted);
  font-size: 12px;
}

.garden-visual {
  position: relative;
  display: grid;
  place-items: center;
  min-height: 210px;
  border: 1px dashed #e6cabd;
  border-radius: 8px;
  background: linear-gradient(180deg, #fffaf5, #fff1ef);
  overflow: hidden;
}

.garden-visual > img {
  width: min(68%, 230px);
  max-height: 190px;
  object-fit: contain;
}

.garden-fallback {
  display: none;
  place-items: center;
  gap: 8px;
  color: var(--muted);
  font-size: 12px;
  text-align: center;
}

.garden-fallback img {
  width: 64px;
  height: 64px;
  object-fit: contain;
}

.garden-visual.missing-stage > img {
  display: none;
}

.garden-visual.missing-stage .garden-fallback {
  display: grid;
}

.garden-progress {
  height: 10px;
  margin-top: 14px;
  border: 1px solid var(--line);
  border-radius: 999px;
  background: #fff;
  overflow: hidden;
}

.garden-progress span {
  display: block;
  width: 0;
  height: 100%;
  border-radius: inherit;
  background: linear-gradient(90deg, var(--pink), #f3c2b4);
}

.reward-form {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 76px 78px;
  gap: 8px;
  margin-bottom: 12px;
}

.reward-card,
.letter-unlock-card,
.outfit-card,
.achievement-card {
  display: grid;
  grid-template-columns: 42px minmax(0, 1fr) auto;
  gap: 10px;
  align-items: center;
  padding: 12px;
  border: 1px solid var(--line);
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.72);
}

.reward-card.exchanged,
.letter-unlock-card.locked,
.outfit-card.locked,
.achievement-card.locked {
  opacity: 0.62;
}

.reward-card img,
.letter-unlock-card img,
.outfit-card img,
.achievement-card img {
  width: 38px;
  height: 38px;
  object-fit: contain;
}

.reward-card h3,
.letter-unlock-card h3,
.outfit-card h3,
.achievement-card h3 {
  margin: 0 0 3px;
  font-size: 14px;
}

.reward-card p,
.letter-unlock-card p,
.outfit-card p,
.achievement-card p {
  margin: 0;
  color: var(--muted);
  font-size: 12px;
  line-height: 1.5;
}

.exchange-button {
  min-height: 34px;
  border: 1px solid var(--line);
  border-radius: 8px;
  padding: 0 10px;
  color: var(--ink);
  background: #fff;
  font-size: 12px;
  font-weight: 700;
}

.exchange-button:disabled {
  color: var(--muted);
  background: #f8f1ec;
}

.animation-container {
  pointer-events: none;
  position: fixed;
  inset: 0;
  z-index: 20;
}

.calendar-header {
  display: grid;
  grid-template-columns: 38px minmax(0, 1fr) 38px;
  gap: 10px;
  align-items: center;
  margin-bottom: 14px;
}

.calendar-header h2 {
  text-align: center;
}

.icon-button {
  display: grid;
  place-items: center;
  width: 38px;
  height: 38px;
  border: 1px solid var(--line);
  border-radius: 8px;
  color: var(--ink);
  background: #fff;
  font-size: 24px;
  line-height: 1;
}

.calendar-weekdays,
.calendar-grid {
  display: grid;
  grid-template-columns: repeat(7, minmax(0, 1fr));
}

.calendar-weekdays {
  margin-bottom: 8px;
  color: var(--muted);
  font-size: 12px;
  font-weight: 700;
  text-align: center;
}

.calendar-grid {
  gap: 6px;
}

.calendar-day {
  display: grid;
  place-items: center;
  gap: 3px;
  min-height: 48px;
  border: 1px solid var(--line);
  border-radius: 8px;
  color: var(--ink);
  background: rgba(255, 255, 255, 0.74);
}

.calendar-day.blank {
  border-color: transparent;
  background: transparent;
  box-shadow: none;
}

.calendar-day.selected {
  border-color: var(--pink);
  background: var(--surface-soft);
  box-shadow: 0 0 0 3px rgba(238, 157, 160, 0.16);
}

.calendar-day span {
  font-size: 12px;
  font-weight: 700;
}

.calendar-day img,
.calendar-day i {
  width: 20px;
  height: 20px;
}

.calendar-day img {
  object-fit: contain;
}

.calendar-legend {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 8px;
  margin-top: 14px;
  color: var(--muted);
  font-size: 12px;
}

.calendar-legend span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.calendar-legend img,
.letter-icon {
  width: 24px;
  height: 24px;
  object-fit: contain;
}

.letter-card {
  padding: 16px;
  border: 1px dashed #e6cabd;
  border-radius: 8px;
  background: var(--cream);
}

.letter-card p {
  color: var(--muted);
  line-height: 1.8;
}

.letter-card .letter-greeting,
.letter-card .letter-sign {
  color: var(--ink);
  font-weight: 700;
}

.letter-card .letter-sign {
  margin-bottom: 0;
  text-align: right;
}

.empty-state {
  display: grid;
  place-items: center;
  gap: 12px;
  min-height: 178px;
  color: var(--muted);
  text-align: center;
}

.empty-state img {
  width: 104px;
}

.bottom-tabs {
  position: fixed;
  left: 50%;
  bottom: max(10px, env(safe-area-inset-bottom));
  z-index: 10;
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 6px;
  width: min(448px, calc(100% - 20px));
  padding: 8px;
  border-radius: 8px;
  transform: translateX(-50%);
}

.bottom-tab {
  display: grid;
  justify-items: center;
  gap: 3px;
  min-height: 58px;
  border: 1px solid transparent;
  border-radius: 8px;
  color: var(--muted);
  background: transparent;
  font-size: 10px;
  font-weight: 700;
}

.bottom-tab img {
  width: 23px;
  height: 23px;
  object-fit: contain;
}

.bottom-tab.active {
  color: var(--ink);
  border-color: var(--line);
  background: var(--surface-soft);
}

@media (min-width: 760px) {
  .app-shell {
    width: min(100%, 920px);
  }

  .view.active {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .page-header {
    grid-column: 1 / -1;
  }

  .hero-panel,
  .home-field-panel,
  .task-composer,
  .task-board,
  .timer-panel,
  .record-panel,
  .calendar-panel,
  .letter-panel,
  .garden-panel,
  .reward-shop-panel,
  .letters-unlock-panel,
  .outfit-panel,
  .album-panel {
    grid-column: span 1;
  }
}

@media (max-width: 360px) {
  .app-shell {
    padding-left: 10px;
    padding-right: 10px;
  }

  .page-header,
  .hero-panel {
    grid-template-columns: 1fr;
  }

  .home-field-grid {
    grid-template-columns: minmax(0, 104px) minmax(0, 1fr);
    gap: 10px;
  }

  .letter-speech {
    max-width: 112px;
    padding: 7px 8px;
    font-size: 11px;
  }

  .header-bunny,
  .hero-bunny {
    width: 96px;
  }

  .form-row,
  .timer-controls,
  .reward-form {
    grid-template-columns: 1fr;
  }

  #timer-complete {
    grid-column: auto;
  }

  .timer-ring strong {
    font-size: 42px;
  }
}

``

## app.js
``javascript
const STORAGE_KEYS = {
  tasks: "fiikun-tasks-v2",
  pomodoroRecords: "fiikun-pomodoro-records-v1",
  strawberryPoints: "fiikun-strawberry-points-v1",
  rewards: "fiikun-rewards-v1",
  letters: "fiikun-letters-v1",
  achievements: "fiikun-achievements-v1",
  fiikun: "fiikun-state-v1",
  garden: "fiikun-garden-v1",
  dailyLetterNotice: "fiikun-daily-letter-notice-v1",
};

const POINTS_PER_TASK = 1;
const GARDEN_MAX_STAGE = 8;

const defaultTasks = [
  createTask("朝のストレッチ 5分", "Tiny", "flower.png"),
  createTask("ベリーダンス基礎練習 20分", "Main", "heart.png"),
  {
    ...createTask("読書ノート 1ページ", "Sub", "book.png"),
    done: true,
    completedAt: new Date().toISOString(),
    pointsAwarded: true,
  },
];

const defaultRewards = [
  createReward("カフェでゆったり時間", 3, "cup.png"),
  createReward("新しい本を読む", 5, "book.png"),
  createReward("小さなプレゼント", 8, "gift.png"),
];

const defaultLetters = [
  {
    id: "first-sprout",
    title: "はじめての芽",
    unlockCondition: "garden.stage >= 2",
    locked: true,
    body: "小さな芽が出たよ。今日の一歩を、ふぃーくんはちゃんと見ていました。",
  },
  {
    id: "first-strawberry",
    title: "いちごの日",
    unlockCondition: "garden.stage >= 5",
    locked: true,
    body: "畑に赤いいちごが実りました。続けてきた時間が、やさしい形になったね。",
  },
];

const defaultAchievements = [
  createAchievement("first-100", "初めて100いちご", "strawberry.png", "100ポイント集める", true),
  createAchievement("thirty-days", "30日継続", "flower.png", "30日続けて記録する", true),
  createAchievement("toeic-100h", "TOEIC100時間", "book.png", "勉強時間が100時間になる", true),
  createAchievement("dance-stage", "ダンス発表会", "heart.png", "大切な発表会を迎える", true),
];

const defaultFiikun = {
  currentOutfit: "normal",
  outfits: [
    {
      id: "normal",
      name: "通常",
      image: "fiikun_normal.png",
      unlockCondition: "default",
      locked: false,
    },
    {
      id: "king",
      name: "王様",
      image: "fiikun_king.png",
      unlockCondition: "strawberryPoints >= 30",
      locked: true,
    },
    {
      id: "princess",
      name: "プリンセス",
      image: "fiikun_princess.png",
      unlockCondition: "garden.stage >= 8",
      locked: true,
    },
    {
      id: "travel",
      name: "旅行",
      image: "fiikun_sailor.png",
      unlockCondition: "future.travelReward",
      locked: true,
    },
  ],
};

const defaultGarden = {
  stage: 1,
  maxStage: GARDEN_MAX_STAGE,
  completedTaskCount: 0,
  stageImages: Array.from({ length: GARDEN_MAX_STAGE }, (_, index) => ({
    stage: index + 1,
    image: `plants/pot_stage${index + 1}.png`,
  })),
};

let tasks = normalizeTasks(loadJson(STORAGE_KEYS.tasks, defaultTasks));
let pomodoroRecords = loadJson(STORAGE_KEYS.pomodoroRecords, []);
let rewards = loadJson(STORAGE_KEYS.rewards, defaultRewards);
let letters = loadJson(STORAGE_KEYS.letters, defaultLetters);
let achievements = loadJson(STORAGE_KEYS.achievements, defaultAchievements);
let fiikun = loadObject(STORAGE_KEYS.fiikun, defaultFiikun);
let garden = loadObject(STORAGE_KEYS.garden, defaultGarden);
let dailyLetterNotice = loadObject(STORAGE_KEYS.dailyLetterNotice, {
  dateKey: "",
  created: false,
  opened: false,
});
let strawberryPoints = loadNumber(STORAGE_KEYS.strawberryPoints);
let activeFilter = "all";
let timerMinutes = 25;
let remainingSeconds = timerMinutes * 60;
let timerRunning = false;
let timerInterval = null;
let visibleMonth = new Date();
let selectedDateKey = toDateKey(new Date());

if (strawberryPoints === null) {
  strawberryPoints = tasks.filter((task) => task.pointsAwarded).length * POINTS_PER_TASK;
}

const views = {
  home: document.querySelector("#home-view"),
  tasks: document.querySelector("#tasks-view"),
  timer: document.querySelector("#timer-view"),
  records: document.querySelector("#records-view"),
  rewards: document.querySelector("#rewards-view"),
};

const taskList = document.querySelector("#task-list");
const homeTaskList = document.querySelector("#home-task-list");
const taskForm = document.querySelector("#task-form");
const taskTitle = document.querySelector("#task-title");
const taskCategory = document.querySelector("#task-category");
const taskIcon = document.querySelector("#task-icon");
const progressLabel = document.querySelector("#progress-label");
const fieldMessage = document.querySelector("#field-message");
const homeFiikunImage = document.querySelector("#home-fiikun-image");
const homeLetterNotice = document.querySelector("#home-letter-notice");
const homeGardenStageImage = document.querySelector("#home-garden-stage-image");
const homeGardenFallback = document.querySelector("#home-garden-fallback");
const homeGardenProgressBar = document.querySelector("#home-garden-progress-bar");
const taskCount = document.querySelector("#task-count");
const todayPomoCount = document.querySelector("#today-pomo-count");
const todayPomoMinutes = document.querySelector("#today-pomo-minutes");
const timerDisplay = document.querySelector("#timer-display");
const timerMode = document.querySelector("#timer-mode");
const timerStart = document.querySelector("#timer-start");
const timerReset = document.querySelector("#timer-reset");
const timerComplete = document.querySelector("#timer-complete");
const recordList = document.querySelector("#record-list");
const recordTotal = document.querySelector("#record-total");
const clearRecords = document.querySelector("#clear-records");
const calendarTitle = document.querySelector("#calendar-title");
const calendarGrid = document.querySelector("#calendar-grid");
const prevMonth = document.querySelector("#prev-month");
const nextMonth = document.querySelector("#next-month");
const letterDate = document.querySelector("#letter-date");
const letterBody = document.querySelector("#letter-body");
const strawberryPointsDisplay = document.querySelector("#strawberry-points");
const gardenStageLabel = document.querySelector("#garden-stage-label");
const gardenStageImage = document.querySelector("#garden-stage-image");
const gardenFallback = document.querySelector("#garden-fallback");
const gardenProgressBar = document.querySelector("#garden-progress-bar");
const gardenMessage = document.querySelector("#garden-message");
const rewardForm = document.querySelector("#reward-form");
const rewardTitleInput = document.querySelector("#reward-title-input");
const rewardCostInput = document.querySelector("#reward-cost-input");
const rewardList = document.querySelector("#reward-list");
const letterUnlockList = document.querySelector("#letter-unlock-list");
const outfitList = document.querySelector("#outfit-list");
const achievementList = document.querySelector("#achievement-list");
const rewardAnimation = document.querySelector("#reward-animation");

document.querySelectorAll(".bottom-tab").forEach((button) => {
  button.addEventListener("click", () => setView(button.dataset.view));
});

document.querySelectorAll("[data-jump]").forEach((button) => {
  button.addEventListener("click", () => setView(button.dataset.jump));
});

document.querySelectorAll(".filter-tab").forEach((button) => {
  button.addEventListener("click", () => {
    activeFilter = button.dataset.filter;
    document.querySelectorAll(".filter-tab").forEach((tab) => tab.classList.remove("active"));
    button.classList.add("active");
    renderTasks();
  });
});

document.querySelectorAll(".duration-chip").forEach((button) => {
  button.addEventListener("click", () => {
    if (timerRunning) return;
    timerMinutes = Number(button.dataset.minutes);
    remainingSeconds = timerMinutes * 60;
    document.querySelectorAll(".duration-chip").forEach((chip) => chip.classList.remove("active"));
    button.classList.add("active");
    renderTimer();
  });
});

taskForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const title = taskTitle.value.trim();
  if (!title) return;

  tasks.unshift(createTask(title, taskCategory.value, taskIcon.value));
  taskForm.reset();
  saveTasks();
  render();
  taskTitle.focus();
});

timerStart.addEventListener("click", () => {
  timerRunning ? pauseTimer() : startTimer();
});

timerReset.addEventListener("click", () => {
  pauseTimer();
  remainingSeconds = timerMinutes * 60;
  renderTimer();
});

timerComplete.addEventListener("click", () => {
  addPomodoroRecord(timerMinutes, "手動で記録");
  pauseTimer();
  remainingSeconds = timerMinutes * 60;
  render();
});

clearRecords.addEventListener("click", () => {
  pomodoroRecords = pomodoroRecords.filter((record) => !isToday(record.completedAt));
  savePomodoroRecords();
  render();
});

prevMonth.addEventListener("click", () => {
  visibleMonth = new Date(visibleMonth.getFullYear(), visibleMonth.getMonth() - 1, 1);
  renderCalendar();
});

nextMonth.addEventListener("click", () => {
  visibleMonth = new Date(visibleMonth.getFullYear(), visibleMonth.getMonth() + 1, 1);
  renderCalendar();
});

rewardForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const title = rewardTitleInput.value.trim();
  const cost = Number(rewardCostInput.value);
  if (!title || !Number.isFinite(cost) || cost < 1) return;

  rewards.unshift(createReward(title, cost, "gift.png"));
  rewardForm.reset();
  rewardCostInput.value = 5;
  saveRewards();
  renderRewards();
});

gardenStageImage.addEventListener("error", () => {
  gardenStageImage.closest(".garden-visual").classList.add("missing-stage");
});

homeGardenStageImage.addEventListener("error", () => {
  homeGardenStageImage.closest(".garden-visual").classList.add("missing-stage");
});

function createTask(title, category, icon) {
  return {
    id: crypto.randomUUID(),
    title,
    category,
    icon,
    done: false,
    completedAt: null,
    pointsAwarded: false,
  };
}

function createReward(title, cost, icon) {
  return {
    id: crypto.randomUUID(),
    title,
    cost,
    icon,
    exchanged: false,
    exchangedAt: null,
  };
}

function createAchievement(id, title, image, unlockCondition, locked) {
  return {
    id,
    title,
    image,
    unlockCondition,
    locked,
  };
}

function loadJson(key, fallback) {
  const saved = localStorage.getItem(key);
  if (!saved) return fallback;

  try {
    const parsed = JSON.parse(saved);
    return Array.isArray(parsed) ? parsed : fallback;
  } catch {
    return fallback;
  }
}

function loadObject(key, fallback) {
  const saved = localStorage.getItem(key);
  if (!saved) return structuredClone(fallback);

  try {
    const parsed = JSON.parse(saved);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : structuredClone(fallback);
  } catch {
    return structuredClone(fallback);
  }
}

function loadNumber(key) {
  const saved = localStorage.getItem(key);
  if (saved === null) return null;
  const value = Number(saved);
  return Number.isFinite(value) ? value : null;
}

function normalizeTasks(items) {
  return items.map((task) => ({
    ...task,
    completedAt: task.done && !task.completedAt ? new Date().toISOString() : task.completedAt || null,
    pointsAwarded: Boolean(task.pointsAwarded || task.done),
  }));
}

function saveTasks() {
  localStorage.setItem(STORAGE_KEYS.tasks, JSON.stringify(tasks));
}

function savePomodoroRecords() {
  localStorage.setItem(STORAGE_KEYS.pomodoroRecords, JSON.stringify(pomodoroRecords));
}

function saveRewards() {
  localStorage.setItem(STORAGE_KEYS.rewards, JSON.stringify(rewards));
}

function saveLetters() {
  localStorage.setItem(STORAGE_KEYS.letters, JSON.stringify(letters));
}

function saveAchievements() {
  localStorage.setItem(STORAGE_KEYS.achievements, JSON.stringify(achievements));
}

function saveFiikun() {
  localStorage.setItem(STORAGE_KEYS.fiikun, JSON.stringify(fiikun));
}

function saveGarden() {
  localStorage.setItem(STORAGE_KEYS.garden, JSON.stringify(garden));
}

function saveDailyLetterNotice() {
  localStorage.setItem(STORAGE_KEYS.dailyLetterNotice, JSON.stringify(dailyLetterNotice));
}

function saveStrawberryPoints() {
  localStorage.setItem(STORAGE_KEYS.strawberryPoints, String(strawberryPoints));
}

function setView(name) {
  if (name === "records") {
    openTodayLetterNotice();
  }

  Object.entries(views).forEach(([key, element]) => {
    element.classList.toggle("active", key === name);
  });

  document.querySelectorAll(".bottom-tab").forEach((button) => {
    const isActive = button.dataset.view === name;
    button.classList.toggle("active", isActive);
    button.setAttribute("aria-current", isActive ? "page" : "false");
  });
}

function render() {
  updateGardenState();
  unlockLetters();
  updateDailyLetterNotice();
  renderTasks();
  renderHome();
  renderTimer();
  renderRecords();
  renderCalendar();
  renderLetter();
  renderRewards();
}

function renderTasks() {
  const visibleTasks =
    activeFilter === "all" ? tasks : tasks.filter((task) => task.category === activeFilter);

  taskCount.textContent = `${visibleTasks.length}件`;
  taskList.innerHTML = "";

  if (visibleTasks.length === 0) {
    taskList.appendChild(createEmptyState("この表示にタスクはありません。", "fiikun_sleep.png"));
    return;
  }

  visibleTasks.forEach((task) => {
    const item = document.createElement("article");
    item.className = `task-item ${task.done ? "done" : ""}`;

    item.innerHTML = `
      <img class="task-icon-img" src="./assets/${task.icon}" alt="" />
      <div>
        <p class="task-title"></p>
        <p class="task-meta">${task.done ? "完了済み" : "これから育てるタスク"}</p>
      </div>
      <span class="category-pill ${task.category}">${task.category}</span>
      <div class="task-actions">
        <button class="check-button" type="button" aria-label="${task.title}を完了切替">${
          task.done ? "✓" : "○"
        }</button>
        <button class="delete-button" type="button" aria-label="${task.title}を削除">×</button>
      </div>
    `;

    item.querySelector(".task-title").textContent = task.title;
    item.querySelector(".check-button").addEventListener("click", () => toggleTask(task.id));
    item.querySelector(".delete-button").addEventListener("click", () => deleteTask(task.id));
    taskList.appendChild(item);
  });
}

function renderHome() {
  const total = tasks.length;
  const done = tasks.filter((task) => task.done).length;
  const todayRecords = getTodayRecords();
  const minutes = todayRecords.reduce((sum, record) => sum + record.minutes, 0);
  const fiikunMood = getHomeFiikunMood(total, done, todayRecords.length);

  renderGardenVisual(
    homeGardenStageImage,
    homeGardenFallback,
    homeGardenProgressBar,
  );
  progressLabel.textContent = `ステージ ${garden.stage} / ${garden.maxStage}`;
  homeFiikunImage.src = `./assets/${fiikunMood.image}`;
  homeFiikunImage.alt = fiikunMood.alt;
  homeLetterNotice.hidden = !hasUnreadTodayLetterNotice();
  fieldMessage.textContent =
    garden.stage >= garden.maxStage
      ? "畑はいちごでいっぱい。ごほうびタブでも同じ満開の畑が見られます。"
      : total === 0
        ? "タスクを達成すると、ごほうびタブのいちご畑も一緒に育ちます。"
        : done === total
          ? `今日のタスクは全部達成。畑はステージ${garden.stage}まで育っています。`
          : `あと${total - done}つ。達成すると畑の成長に近づきます。`;

  todayPomoCount.textContent = `${todayRecords.length}回`;
  todayPomoMinutes.textContent = `${minutes}分`;

  homeTaskList.innerHTML = "";
  tasks.slice(0, 4).forEach((task) => {
    const item = document.createElement("article");
    item.className = `mini-task ${task.done ? "done" : ""}`;
    item.innerHTML = `
      <img src="./assets/${task.icon}" alt="" />
      <div>
        <p class="task-title"></p>
        <p class="task-meta">${task.done ? "できた" : "今日の約束"}</p>
      </div>
      <span class="category-pill ${task.category}">${task.category}</span>
    `;
    item.querySelector(".task-title").textContent = task.title;
    homeTaskList.appendChild(item);
  });

  if (tasks.length === 0) {
    homeTaskList.appendChild(createEmptyState("タスクを追加すると、ここに表示されます。", "fiikun_think.png"));
  }
}

function renderTimer() {
  const minutes = Math.floor(remainingSeconds / 60);
  const seconds = remainingSeconds % 60;
  timerDisplay.textContent = `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  timerStart.textContent = timerRunning ? "一時停止" : "スタート";
  timerMode.textContent = timerRunning ? "集中しています" : "集中時間";
}

function renderRecords() {
  const todayRecords = getTodayRecords();
  const minutes = todayRecords.reduce((sum, record) => sum + record.minutes, 0);

  recordTotal.textContent = `${todayRecords.length}回 / ${minutes}分`;
  recordList.innerHTML = "";

  if (todayRecords.length === 0) {
    recordList.appendChild(createEmptyState("まだ今日の記録はありません。", "fiikun_nightcap.png"));
    return;
  }

  todayRecords
    .slice()
    .reverse()
    .forEach((record) => {
      const item = document.createElement("article");
      const time = new Date(record.completedAt).toLocaleTimeString("ja-JP", {
        hour: "2-digit",
        minute: "2-digit",
      });

      item.className = "record-item";
      item.innerHTML = `
        <img src="./assets/strawberry.png" alt="" />
        <div>
          <p class="record-title">${record.minutes}分 集中</p>
          <p class="record-meta">${time}に記録</p>
        </div>
        <span class="category-pill Main">Pomodoro</span>
      `;
      recordList.appendChild(item);
    });
}

function renderCalendar() {
  const year = visibleMonth.getFullYear();
  const month = visibleMonth.getMonth();
  const firstDay = new Date(year, month, 1);
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const leadingBlankCount = firstDay.getDay();

  calendarTitle.textContent = `${year}年${month + 1}月`;
  calendarGrid.innerHTML = "";

  for (let index = 0; index < leadingBlankCount; index += 1) {
    const blank = document.createElement("div");
    blank.className = "calendar-day blank";
    calendarGrid.appendChild(blank);
  }

  for (let day = 1; day <= daysInMonth; day += 1) {
    const date = new Date(year, month, day);
    const dateKey = toDateKey(date);
    const achievement = getAchievementForDate(dateKey);
    const button = document.createElement("button");
    button.className = `calendar-day ${dateKey === selectedDateKey ? "selected" : ""}`;
    button.type = "button";
    button.setAttribute("aria-label", `${month + 1}月${day}日`);
    button.innerHTML = `
      <span>${day}</span>
      ${achievement.icon ? `<img src="./assets/${achievement.icon}" alt="" />` : "<i></i>"}
    `;
    button.addEventListener("click", () => {
      selectedDateKey = dateKey;
      renderCalendar();
      renderLetter();
    });
    calendarGrid.appendChild(button);
  }
}

function renderLetter() {
  const date = parseDateKey(selectedDateKey);
  const achievement = getAchievementForDate(selectedDateKey);

  letterDate.textContent = date.toLocaleDateString("ja-JP", {
    month: "long",
    day: "numeric",
    weekday: "short",
  });

  const messages = {
    gift:
      "今日はタスクも集中時間もぜんぶ育ったね。いちご畑にプレゼントが届くくらい、すてきな一日でした。",
    strawberry:
      "Mainタスクをがんばった日だね。大きないちごがひとつ、しっかり赤くなりました。",
    flower:
      "Subタスクをていねいに進めた日だね。小さなお花が、畑のそばでふんわり咲いています。",
    clock:
      "ポモドーロで集中できた日だね。時計の針のぶんだけ、未来のあなたが楽になっています。",
    none:
      "この日はまだ記録がありません。何もない日も、休むための大切な余白だよ。",
  };

  letterBody.textContent = messages[achievement.type];
}

function renderRewards() {
  renderGarden();
  renderRewardList();
  renderLetterUnlocks();
  renderOutfits();
  renderAchievements();
}

function renderGarden() {
  renderGardenVisual(
    gardenStageImage,
    gardenFallback,
    gardenProgressBar,
  );

  strawberryPointsDisplay.textContent = strawberryPoints;
  gardenStageLabel.textContent = `ステージ ${garden.stage} / ${garden.maxStage}`;
  gardenMessage.textContent =
    garden.stage >= garden.maxStage
      ? "畑はいちごでいっぱい。次はごほうびや衣装を増やしていけます。"
      : `あと${Math.max(0, garden.stage)}回ほど達成すると、次の成長が近づきます。`;
}

function renderGardenVisual(stageImage, fallback, progressBar) {
  const currentStageImage = garden.stageImages.find((item) => item.stage === garden.stage);
  const imagePath = currentStageImage?.image || `plants/pot_stage${garden.stage}.png`;
  const percent = Math.round((garden.stage / garden.maxStage) * 100);

  stageImage.closest(".garden-visual").classList.remove("missing-stage");
  stageImage.src = `./assets/${imagePath}`;
  fallback.querySelector("span").textContent = `assets/${imagePath}`;
  progressBar.style.width = `${percent}%`;

  return { imagePath, percent };
}

function getHomeFiikunMood(totalTasks, doneTasks, todayPomodoroCount) {
  const hasPomodoro = todayPomodoroCount > 0;
  const hasTasks = totalTasks > 0;
  const allTasksDone = hasTasks && doneTasks === totalTasks;

  if (allTasksDone && hasPomodoro) {
    return { image: "fiikun_strawberry.png", alt: "いちごを持つふぃーくん" };
  }
  if (allTasksDone) {
    return { image: "fiikun_happy.png", alt: "笑顔のふぃーくん" };
  }
  if (doneTasks > 0 && hasPomodoro) {
    return { image: "fiikun_surprised.png", alt: "うれしそうなふぃーくん" };
  }
  if (doneTasks > 0) {
    return { image: "fiikun_happy.png", alt: "にこにこのふぃーくん" };
  }
  if (hasPomodoro) {
    return { image: "fiikun_stand.png", alt: "応援するふぃーくん" };
  }
  if (hasTasks) {
    return { image: "fiikun_think.png", alt: "考えるふぃーくん" };
  }
  return { image: "fiikun_normal.png", alt: "ふぃーくん" };
}

function renderRewardList() {
  rewardList.innerHTML = "";

  rewards.forEach((reward) => {
    const canExchange = !reward.exchanged && strawberryPoints >= reward.cost;
    const item = document.createElement("article");
    item.className = `reward-card ${reward.exchanged ? "exchanged" : ""}`;
    item.innerHTML = `
      <img src="./assets/${reward.icon}" alt="" />
      <div>
        <h3></h3>
        <p>${reward.exchanged ? "交換済み" : `${reward.cost}いちごで交換`}</p>
      </div>
      <button class="exchange-button" type="button" ${canExchange ? "" : "disabled"}>
        ${reward.exchanged ? "済" : "交換"}
      </button>
    `;
    item.querySelector("h3").textContent = reward.title;
    item.querySelector("button").addEventListener("click", () => exchangeReward(reward.id));
    rewardList.appendChild(item);
  });
}

function renderLetterUnlocks() {
  letterUnlockList.innerHTML = "";

  letters.forEach((letter) => {
    const item = document.createElement("article");
    item.className = `letter-unlock-card ${letter.locked ? "locked" : ""}`;
    item.innerHTML = `
      <img src="./assets/letter.png" alt="" />
      <div>
        <h3></h3>
        <p>${letter.locked ? `未解放: ${letter.unlockCondition}` : letter.body}</p>
      </div>
      <span class="category-pill ${letter.locked ? "Sub" : "Main"}">${letter.locked ? "Locked" : "Open"}</span>
    `;
    item.querySelector("h3").textContent = letter.title;
    letterUnlockList.appendChild(item);
  });
}

function renderOutfits() {
  outfitList.innerHTML = "";

  fiikun.outfits.forEach((outfit) => {
    const item = document.createElement("article");
    item.className = `outfit-card ${outfit.locked ? "locked" : ""}`;
    item.innerHTML = `
      <img src="./assets/${outfit.image}" alt="" />
      <div>
        <h3></h3>
        <p>${outfit.locked ? `未解放: ${outfit.unlockCondition}` : "選択できます"}</p>
      </div>
      <span class="category-pill ${outfit.locked ? "Sub" : "Tiny"}">${outfit.locked ? "Locked" : "Now"}</span>
    `;
    item.querySelector("h3").textContent = outfit.name;
    outfitList.appendChild(item);
  });
}

function renderAchievements() {
  achievementList.innerHTML = "";

  achievements.forEach((achievement) => {
    const item = document.createElement("article");
    item.className = `achievement-card ${achievement.locked ? "locked" : ""}`;
    item.innerHTML = `
      <img src="./assets/${achievement.image}" alt="" />
      <div>
        <h3></h3>
        <p>${achievement.unlockCondition}</p>
      </div>
      <span class="category-pill ${achievement.locked ? "Sub" : "Main"}">${achievement.locked ? "未達成" : "達成"}</span>
    `;
    item.querySelector("h3").textContent = achievement.title;
    achievementList.appendChild(item);
  });
}

function createEmptyState(message, image) {
  const empty = document.createElement("div");
  empty.className = "empty-state";
  empty.innerHTML = `
    <img src="./assets/${image}" alt="" />
    <p>${message}</p>
  `;
  return empty;
}

function toggleTask(id) {
  tasks = tasks.map((task) => {
    if (task.id !== id) return task;
    const done = !task.done;
    const shouldAwardPoints = done && !task.pointsAwarded;

    if (shouldAwardPoints) {
      strawberryPoints += POINTS_PER_TASK;
      saveStrawberryPoints();
    }

    return {
      ...task,
      done,
      completedAt: done ? new Date().toISOString() : null,
      pointsAwarded: task.pointsAwarded || shouldAwardPoints,
    };
  });
  saveTasks();
  render();
}

function deleteTask(id) {
  tasks = tasks.filter((task) => task.id !== id);
  saveTasks();
  render();
}

function exchangeReward(id) {
  const reward = rewards.find((item) => item.id === id);
  if (!reward || reward.exchanged || strawberryPoints < reward.cost) return;

  strawberryPoints -= reward.cost;
  reward.exchanged = true;
  reward.exchangedAt = new Date().toISOString();
  saveStrawberryPoints();
  saveRewards();
  prepareRewardAnimation();
  renderRewards();
}

function prepareRewardAnimation() {
  rewardAnimation.dataset.ready = "true";
}

function startTimer() {
  timerRunning = true;
  renderTimer();
  timerInterval = window.setInterval(() => {
    remainingSeconds -= 1;
    if (remainingSeconds <= 0) {
      addPomodoroRecord(timerMinutes, "自動で記録");
      pauseTimer();
      remainingSeconds = timerMinutes * 60;
      render();
      return;
    }
    renderTimer();
  }, 1000);
}

function pauseTimer() {
  timerRunning = false;
  if (timerInterval) {
    window.clearInterval(timerInterval);
    timerInterval = null;
  }
  renderTimer();
}

function addPomodoroRecord(minutes, note) {
  pomodoroRecords.push({
    id: crypto.randomUUID(),
    minutes,
    note,
    completedAt: new Date().toISOString(),
  });
  savePomodoroRecords();
}

function updateGardenState() {
  garden.completedTaskCount = tasks.filter((task) => task.pointsAwarded).length;
  garden.stage = Math.min(garden.maxStage, Math.max(1, garden.completedTaskCount + 1));
  saveGarden();
}

function unlockLetters() {
  letters = letters.map((letter) => {
    if (letter.id === "first-sprout" && garden.stage >= 2) return { ...letter, locked: false };
    if (letter.id === "first-strawberry" && garden.stage >= 5) return { ...letter, locked: false };
    return letter;
  });
  saveLetters();
}

function updateDailyLetterNotice() {
  const todayKey = toDateKey(new Date());
  const achievement = getAchievementForDate(todayKey);

  if (dailyLetterNotice.dateKey !== todayKey) {
    dailyLetterNotice = {
      dateKey: todayKey,
      created: false,
      opened: false,
    };
  }

  if (achievement.type !== "none" && !dailyLetterNotice.created && !dailyLetterNotice.opened) {
    dailyLetterNotice = {
      dateKey: todayKey,
      created: true,
      opened: false,
    };
  }

  saveDailyLetterNotice();
}

function hasUnreadTodayLetterNotice() {
  return (
    dailyLetterNotice.dateKey === toDateKey(new Date()) &&
    dailyLetterNotice.created &&
    !dailyLetterNotice.opened
  );
}

function openTodayLetterNotice() {
  if (!hasUnreadTodayLetterNotice()) return;

  dailyLetterNotice = {
    ...dailyLetterNotice,
    opened: true,
  };
  saveDailyLetterNotice();

  if (homeLetterNotice) {
    homeLetterNotice.hidden = true;
  }
}

function getTodayRecords() {
  return pomodoroRecords.filter((record) => isToday(record.completedAt));
}

function getAchievementForDate(dateKey) {
  const tasksOnDate = tasks.filter((task) => task.completedAt && toDateKey(task.completedAt) === dateKey);
  const hasMain = tasksOnDate.some((task) => task.category === "Main");
  const hasSub = tasksOnDate.some((task) => task.category === "Sub");
  const hasPomodoro = pomodoroRecords.some((record) => toDateKey(record.completedAt) === dateKey);
  const allTasksDoneOnDate =
    tasks.length > 0 && tasks.every((task) => task.completedAt && toDateKey(task.completedAt) === dateKey);

  if (allTasksDoneOnDate && hasPomodoro) return { type: "gift", icon: "gift.png" };
  if (hasPomodoro) return { type: "clock", icon: "clock.png" };
  if (hasMain) return { type: "strawberry", icon: "strawberry.png" };
  if (hasSub) return { type: "flower", icon: "flower.png" };
  return { type: "none", icon: "" };
}

function isToday(value) {
  return toDateKey(value) === toDateKey(new Date());
}

function toDateKey(value) {
  const date = value instanceof Date ? value : new Date(value);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function parseDateKey(dateKey) {
  const [year, month, day] = dateKey.split("-").map(Number);
  return new Date(year, month - 1, day);
}

saveTasks();
savePomodoroRecords();
saveRewards();
saveLetters();
saveAchievements();
saveFiikun();
saveStrawberryPoints();
saveDailyLetterNotice();
render();

``

